/**
 * 
 */
package com.shyam.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shyam.springboot.model.Task;
import com.shyam.springboot.model.User;
import com.shyam.springboot.repositories.TaskRepository;
import com.shyam.springboot.repositories.UserRepository;

/**
 * @author shysatya
 *
 */
@Service("taskService")
@Transactional
public class TaskServiceImpl implements TaskService{

	@Autowired
	public TaskRepository taskRepository;
	
	@Override
	public Task findById(Long id) {
		// TODO Auto-generated method stub
		return taskRepository.findOne(id);
	}

	@Override
	public Task findByName(String name) {
		// TODO Auto-generated method stub
		return taskRepository.findByName(name);
	}

	@Override
	public void saveTask(Task task) {
		taskRepository.save(task);
		
	}

	@Override
	public void updateTask(Task task) {
		saveTask(task);
		
	}

	@Override
	public void deleteTaskById(Long id) {
		taskRepository.delete(id);
		
	}

	@Override
	public void deleteAllTasks() {
		taskRepository.deleteAll();
	}

	@Override
	public List<Task> findAllTasks() {
		return taskRepository.findAll();
	}

	@Override
	public boolean isTaskExist(Task task) {
		return findByName(task.getName()) != null;
	}

}
