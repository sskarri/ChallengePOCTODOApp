package com.shyam.springboot.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.shyam.springboot.model.Task;
import com.shyam.springboot.repositories.TaskRepository;

@Component
public interface TaskService{

	Task findById(Long id);

	Task findByName(String name);

	void saveTask(Task task);

	void updateTask(Task task);

	void deleteTaskById(Long id);

	void deleteAllTasks();

	List<Task> findAllTasks();

	boolean isTaskExist(Task task);
	
}
