package com.shyam.springboot.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AppController {

	@RequestMapping("/")
	String home(ModelMap modal) {
		modal.addAttribute("title","CRUD Example");
		return "login";
	}

	@RequestMapping("/partials/{page}")
	String partialHandler(@PathVariable("page") final String page) {
		return page;
	}
	
	@RequestMapping("/index")
	String home1(ModelMap modal) {
		modal.addAttribute("title","CRUD POC");
		return "index";
	}
	@RequestMapping("/logout")
	String logout(HttpSession session) {
		session.invalidate();
		
		return "login";
	}
	@RequestMapping("/login")
	String login(HttpSession session) {
		session.invalidate();
		
		return "redirect:/";
	}
	@RequestMapping("/userServ")
	String userSer(ModelMap modal) {
		modal.addAttribute("title","User service");
		return "user";
	}
	@RequestMapping("/taskServ")
	String tasker(ModelMap modal) {
		modal.addAttribute("title","Task service");
		return "task";
	}

}
