var app2 = angular.module('TaskApp',['ui.router','ngStorage']);

app2.constant('urls', {
    BASE: 'http://localhost:8080/ChallengePOC',
    USER_SERVICE_API : 'http://localhost:8080/ChallengePOC/api/task/'
});

app2.config(['$stateProvider', '$urlRouterProvider',
    function($stateProvider, $urlRouterProvider) {

        $stateProvider
            .state('task', {
                url: '/',
                templateUrl: 'partials/tasklist',
                controller:'TaskController',
                controllerAs:'ctrl',
                resolve: {
                    users: function ($q, TaskService) {
                        console.log('Load all tasks');
                        var deferred = $q.defer();
                        TaskService.loadAllUsers().then(deferred.resolve, deferred.resolve);
                        return deferred.promise;
                    }
                }
            });
        $urlRouterProvider.otherwise('/');
    }]);

